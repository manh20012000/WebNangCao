﻿$(function () {
    $('#boxAlert').removeClass('hide');
    $('#boxAlert').delay(1000).slideUp(500);

})