﻿namespace ShopWatch.Areas.NhanVien.Controllers
{
    internal class DHEntities
    {
        public DHEntities()
        {
        }
    }
}