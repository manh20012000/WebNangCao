﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopWatch.Session
{
    public class NhanVienLogin
    {
        public string email { set; get; }
        public string password { set; get; }
    }
}