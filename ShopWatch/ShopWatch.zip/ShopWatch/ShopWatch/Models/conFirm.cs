﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopWatch.Models
{
    public class conFirm
    {
        public int so1;
        public int so2;
        public int so3;
        public int so4;
        public int so5;
        public int so6;
        public conFirm(int s1, int s2, int s3, int s4, int s5, int s6)
        {
            this.so1 = s1;
            this.so2 = s2;
            this.so3 = s3;
            this.so4 = s4;
            this.so5 = s5;
            this.so6 = s6;
               
        }
    }
}