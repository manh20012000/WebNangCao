﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ShopWatch.Models
{
    [MetadataTypeAttribute(typeof(MetaData.TAIKHOAN_METADATA))]
    public partial class TaiKhoan_MD

    {

    }
}